import os, requests
from flask import Flask, request, jsonify, send_from_directory
from dotenv import load_dotenv

load_dotenv()
app=Flask(__name__, static_folder=None)
API_KEY=os.getenv("IMEI_API_KEY","")
API_BASE=os.getenv("IMEI_API_BASE","https://api-client.imei.org/api").rstrip("/")
SERVICE_ID=os.getenv("FMI_SERVICE_ID","171")

@app.get("/")
def home():
    return send_from_directory(".", "index.html")

@app.post("/api/check")
def check():
    data=request.get_json(silent=True) or {}
    value=(data.get("input") or "").strip()
    if not value: return jsonify(ok=False,error="Serial Number required"),400
    if not API_KEY: return jsonify(ok=False,error="API key not configured"),500
    try:
        r=request.get(f"{API_BASE}/submit",
                      params={"apikey":API_KEY,"service_id":SERVICE_ID,"input":value},
                      timeout=30)
        r.raise_for_status()
        raw=r.json()
        if raw.get("status") != 1:
            return jsonify(ok=False,error=raw),400
        response=raw.get("response",{})
        services=response.get("services") if isinstance(response,dict) else None
        result=services[0] if isinstance(services,list) and services else response
        return jsonify(ok=True,result=result)
    except Exception as e:
        return jsonify(ok=False,error=str(e)),502

if __name__=="__main__":
    app.run(host="0.0.0.0",port=int(os.getenv("PORT","5000")))
